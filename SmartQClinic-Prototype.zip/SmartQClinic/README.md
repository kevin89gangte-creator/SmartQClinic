# SmartQ Clinic — first prototype

## What this prototype does
- Patient view: create a live-queue entry or choose a scheduled appointment date/time.
- Clinic desk view: add walk-ins, call next, complete, skip, and view the queue.
- Generates sequential token numbers and shows a rough waiting estimate.

## Important limitations
This is a local demonstration prototype. Data is stored only in the browser on the device where it was entered. It does NOT sync patient phones with the clinic desk, send notifications, authenticate clinic staff, or provide reliable appointment-slot capacity management. Do not enter real patient names, phone numbers, symptoms, or medical information.

## Files
- `index.html`: complete prototype app
- `manifest.webmanifest`: installable web-app metadata
- `sw.js`: basic offline shell cache

## How to try it on Android
1. Extract the ZIP on your phone.
2. Open `index.html` in Chrome if your file manager offers that option. Some Android file managers block local app features.
3. For proper installation with an app icon, the files must be hosted over HTTPS (for example, a free static hosting service). Then open the hosted address in Chrome, use the three-dot menu, and choose **Install app** or **Add to Home screen**.
4. Patient and Clinic desk tabs currently share data only in the same browser on the same device.

## Next development stage
Connect a cloud database and secure staff sign-in so multiple phones can see one live queue. Add proper slot capacity, clinic opening hours, queue pause/close controls, cancellation/no-show rules, privacy notice, and push notifications before any real clinic pilot.
