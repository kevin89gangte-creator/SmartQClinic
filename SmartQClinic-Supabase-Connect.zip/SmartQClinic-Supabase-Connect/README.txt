SMARTQ CLINIC — SUPABASE CONNECTION PACKAGE

Files in this package:
1) supabase-setup.sql  - run this once in Supabase SQL Editor.
2) index.html          - replace the current index.html in GitHub with this file.
3) sw.js               - replace the current sw.js in GitHub with this file.

IMPORTANT
- Do not run this SQL until you have confirmed you are in the correct Supabase project (project reference: slpnvgtkrxtcgqjwudsy).
- The SQL extends the existing SmartQ tables created in the earlier setup. It is intended to be run once.
- The browser app contains only the Supabase Project URL and Publishable key. Never place a database password, sb_secret_ key or service_role key in index.html.
- Use fictional test data only. Before real patient use, add phone verification/anti-spam controls, review privacy obligations, backups, support procedures and operational safeguards.
- The app polls the public queue summary every 10 seconds. Patient identity details are only available to signed-in clinic members through RLS-protected tables.
- Scheduled appointments use a demo capacity of 3 bookings per time slot. Appointment slots are not called until their scheduled time.

Suggested deployment order:
A. Run supabase-setup.sql in Supabase SQL Editor and confirm success.
B. In GitHub, replace index.html with this package's index.html.
C. Replace sw.js with this package's sw.js.
D. Wait for GitHub Pages deployment, then open the website in Chrome and refresh/clear old site cache if needed.
E. Test with two devices using fake names. Sign into Clinic desk using the Supabase Auth user that was added to clinic_members as owner.
