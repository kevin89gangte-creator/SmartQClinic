-- SmartQ Clinic: secure shared-queue backend setup
-- Run once in Supabase SQL Editor while signed in as project owner.
-- This extends the existing five-table schema created earlier.

-- Extra field used as a private, random patient ticket reference.
alter table public.queue_entries
  add column if not exists tracking_code uuid default gen_random_uuid();
update public.queue_entries
  set tracking_code = gen_random_uuid()
  where tracking_code is null;
alter table public.queue_entries
  alter column tracking_code set default gen_random_uuid();
alter table public.queue_entries
  alter column tracking_code set not null;
create unique index if not exists queue_entries_tracking_code_uidx
  on public.queue_entries (tracking_code);

-- Capacity per 30-minute appointment slot. Three is a conservative demo default.
alter table public.clinics
  add column if not exists appointment_slot_capacity integer not null default 3;
alter table public.clinics
  drop constraint if exists clinics_appointment_slot_capacity_check;
alter table public.clinics
  add constraint clinics_appointment_slot_capacity_check
  check (appointment_slot_capacity between 1 and 50);

-- Public patient booking. Public callers can create a booking only through this
-- function; they cannot read the appointments/queue tables directly.
create or replace function public.smartq_book_visit(
  p_patient_name text,
  p_patient_phone text default null,
  p_visit_type text default 'live',
  p_appointment_date date default null,
  p_appointment_time time default null
)
returns table (
  token_number integer,
  queue_date date,
  status text,
  tracking_code uuid,
  appointment_date date,
  appointment_time time
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_clinic_id uuid;
  v_queue_date date;
  v_next_token integer;
  v_appointment_id uuid;
  v_tracking_code uuid;
  v_slot_capacity integer;
  v_slot_count integer;
  v_local_now timestamp;
begin
  if p_patient_name is null or length(trim(p_patient_name)) < 2
     or length(trim(p_patient_name)) > 60 then
    raise exception 'Please enter a name between 2 and 60 characters.';
  end if;

  if p_patient_phone is not null and length(trim(p_patient_phone)) > 20 then
    raise exception 'Mobile number is too long.';
  end if;

  if coalesce(p_visit_type, '') not in ('live', 'appointment') then
    raise exception 'Invalid visit type.';
  end if;

  select c.id, c.appointment_slot_capacity
    into v_clinic_id, v_slot_capacity
  from public.clinics c
  where c.slug = 'smartq-demo-clinic' and c.is_active = true;

  if v_clinic_id is null then
    raise exception 'SmartQ Clinic is not currently accepting bookings.';
  end if;

  v_local_now := timezone('Asia/Kolkata', now());

  if p_visit_type = 'appointment' then
    if p_appointment_date is null or p_appointment_time is null then
      raise exception 'Choose an appointment date and time.';
    end if;
    if p_appointment_date < v_local_now::date
       or (p_appointment_date = v_local_now::date and p_appointment_time <= v_local_now::time) then
      raise exception 'Choose a future appointment slot.';
    end if;
    if p_appointment_time not in (
      time '09:00', time '09:30', time '10:00', time '10:30',
      time '11:00', time '11:30', time '12:00'
    ) then
      raise exception 'That appointment time is not available.';
    end if;

    -- Serialize bookings for the same clinic/date/time before checking capacity.
    perform pg_advisory_xact_lock(
      hashtextextended(v_clinic_id::text || ':slot:' || p_appointment_date::text || ':' || p_appointment_time::text, 0)
    );

    select count(*) into v_slot_count
    from public.appointments a
    where a.clinic_id = v_clinic_id
      and a.appointment_date = p_appointment_date
      and a.appointment_time = p_appointment_time
      and a.status in ('booked', 'checked_in');

    if v_slot_count >= v_slot_capacity then
      raise exception 'That appointment slot is full. Please choose another time.';
    end if;

    insert into public.appointments (
      clinic_id, patient_name, patient_phone, appointment_date, appointment_time, status
    ) values (
      v_clinic_id, trim(p_patient_name), nullif(trim(coalesce(p_patient_phone, '')), ''),
      p_appointment_date, p_appointment_time, 'booked'
    ) returning id into v_appointment_id;

    v_queue_date := p_appointment_date;
  else
    v_queue_date := v_local_now::date;
  end if;

  -- One counter per clinic/date, safe when several phones book at once.
  perform pg_advisory_xact_lock(
    hashtextextended(v_clinic_id::text || ':queue:' || v_queue_date::text, 0)
  );

  select coalesce(max(q.token_number), 0) + 1
    into v_next_token
  from public.queue_entries q
  where q.clinic_id = v_clinic_id and q.queue_date = v_queue_date;

  insert into public.queue_entries (
    clinic_id, appointment_id, patient_name, patient_phone,
    queue_date, token_number, source, status
  ) values (
    v_clinic_id, v_appointment_id, trim(p_patient_name),
    nullif(trim(coalesce(p_patient_phone, '')), ''),
    v_queue_date, v_next_token,
    case when p_visit_type = 'appointment' then 'appointment' else 'walk_in' end,
    'waiting'
  ) returning queue_entries.tracking_code into v_tracking_code;

  return query
    select v_next_token, v_queue_date, 'waiting'::text, v_tracking_code,
      case when p_visit_type = 'appointment' then p_appointment_date else null end,
      case when p_visit_type = 'appointment' then p_appointment_time else null end;
end;
$$;

-- Public queue summary contains no patient names or phone numbers.
create or replace function public.smartq_public_status()
returns table (
  queue_date date,
  now_serving integer,
  waiting_count bigint,
  estimated_wait_minutes integer
)
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select
    (timezone('Asia/Kolkata', now()))::date,
    max(q.token_number) filter (where q.status = 'serving'),
    count(*) filter (where q.status = 'waiting'),
    (count(*) filter (where q.status = 'waiting') * 10)::integer
  from public.queue_entries q
  join public.clinics c on c.id = q.clinic_id
  where c.slug = 'smartq-demo-clinic'
    and c.is_active = true
    and q.queue_date = (timezone('Asia/Kolkata', now()))::date;
$$;

-- Ticket lookup requires the unguessable tracking UUID and returns no PII.
create or replace function public.smartq_track_ticket(p_tracking_code uuid)
returns table (
  token_number integer,
  queue_date date,
  status text,
  patients_ahead bigint,
  estimated_wait_minutes integer,
  appointment_date date,
  appointment_time time
)
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select
    mine.token_number,
    mine.queue_date,
    mine.status,
    case when mine.status = 'waiting' then (
      select count(*)
      from public.queue_entries ahead
      where ahead.clinic_id = mine.clinic_id
        and ahead.queue_date = mine.queue_date
        and ahead.token_number < mine.token_number
        and ahead.status in ('waiting', 'serving')
    ) else 0 end,
    case when mine.status = 'waiting' then (
      select (count(*) * 10)::integer
      from public.queue_entries ahead
      where ahead.clinic_id = mine.clinic_id
        and ahead.queue_date = mine.queue_date
        and ahead.token_number < mine.token_number
        and ahead.status in ('waiting', 'serving')
    ) else 0 end,
    ap.appointment_date,
    ap.appointment_time
  from public.queue_entries mine
  join public.clinics c on c.id = mine.clinic_id and c.slug = 'smartq-demo-clinic'
  left join public.appointments ap on ap.id = mine.appointment_id
  where mine.tracking_code = p_tracking_code
  limit 1;
$$;

-- Receptionist-only walk-in creation.
create or replace function public.smartq_staff_add_walkin(
  p_patient_name text,
  p_patient_phone text default null
)
returns table (token_number integer, queue_entry_id uuid)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_clinic_id uuid;
  v_today date := (timezone('Asia/Kolkata', now()))::date;
  v_next_token integer;
  v_entry_id uuid;
begin
  select c.id into v_clinic_id
  from public.clinics c
  where c.slug = 'smartq-demo-clinic' and c.is_active = true;

  if auth.uid() is null or v_clinic_id is null
     or not public.is_clinic_member(v_clinic_id) then
    raise exception 'You are not authorised to manage this clinic.';
  end if;

  if p_patient_name is null or length(trim(p_patient_name)) < 2
     or length(trim(p_patient_name)) > 60 then
    raise exception 'Please enter a name between 2 and 60 characters.';
  end if;

  perform pg_advisory_xact_lock(
    hashtextextended(v_clinic_id::text || ':queue:' || v_today::text, 0)
  );

  select coalesce(max(q.token_number), 0) + 1 into v_next_token
  from public.queue_entries q
  where q.clinic_id = v_clinic_id and q.queue_date = v_today;

  insert into public.queue_entries (
    clinic_id, patient_name, patient_phone, queue_date, token_number, source, status
  ) values (
    v_clinic_id, trim(p_patient_name), nullif(trim(coalesce(p_patient_phone, '')), ''),
    v_today, v_next_token, 'walk_in', 'waiting'
  ) returning id into v_entry_id;

  return query select v_next_token, v_entry_id;
end;
$$;

-- Receptionist-only next-patient action. The lock prevents two staff devices
-- from calling two patients at the same time.
create or replace function public.smartq_staff_call_next()
returns table (queue_entry_id uuid, token_number integer, patient_name text, source text, status text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_clinic_id uuid;
  v_today date := (timezone('Asia/Kolkata', now()))::date;
  v_current uuid;
  v_next_id uuid;
  v_next_token integer;
  v_next_name text;
  v_next_source text;
begin
  select c.id into v_clinic_id
  from public.clinics c
  where c.slug = 'smartq-demo-clinic' and c.is_active = true;

  if auth.uid() is null or v_clinic_id is null
     or not public.is_clinic_member(v_clinic_id) then
    raise exception 'You are not authorised to manage this clinic.';
  end if;

  perform pg_advisory_xact_lock(
    hashtextextended(v_clinic_id::text || ':queue:' || v_today::text, 0)
  );

  select q.id into v_current
  from public.queue_entries q
  where q.clinic_id = v_clinic_id and q.queue_date = v_today and q.status = 'serving'
  limit 1;

  if v_current is not null then
    raise exception 'Complete or skip the current patient first.';
  end if;

  select q.id, q.token_number, q.patient_name, q.source
    into v_next_id, v_next_token, v_next_name, v_next_source
  from public.queue_entries q
  left join public.appointments ap on ap.id = q.appointment_id
  where q.clinic_id = v_clinic_id
    and q.queue_date = v_today
    and q.status = 'waiting'
    and (q.source <> 'appointment' or
         (ap.appointment_date = v_today and ap.appointment_time <= timezone('Asia/Kolkata', now())::time))
  order by q.token_number
  for update of q skip locked
  limit 1;

  if v_next_id is null then
    return;
  end if;

  update public.queue_entries q
  set status = 'serving', called_at = now()
  where q.id = v_next_id;

  return query select v_next_id, v_next_token, v_next_name,
    v_next_source, 'serving'::text;
end;
$$;

-- Receptionist-only completion or skip action.
create or replace function public.smartq_staff_finish_current(p_action text)
returns table (token_number integer, status text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_clinic_id uuid;
  v_today date := (timezone('Asia/Kolkata', now()))::date;
  v_entry_id uuid;
  v_token integer;
  v_appointment_id uuid;
begin
  select c.id into v_clinic_id
  from public.clinics c
  where c.slug = 'smartq-demo-clinic' and c.is_active = true;

  if auth.uid() is null or v_clinic_id is null
     or not public.is_clinic_member(v_clinic_id) then
    raise exception 'You are not authorised to manage this clinic.';
  end if;

  if p_action not in ('completed', 'skipped') then
    raise exception 'Invalid queue action.';
  end if;

  perform pg_advisory_xact_lock(
    hashtextextended(v_clinic_id::text || ':queue:' || v_today::text, 0)
  );

  select q.id, q.token_number, q.appointment_id
    into v_entry_id, v_token, v_appointment_id
  from public.queue_entries q
  where q.clinic_id = v_clinic_id
    and q.queue_date = v_today
    and q.status = 'serving'
  for update;

  if v_entry_id is null then
    raise exception 'There is no patient currently being served.';
  end if;

  update public.queue_entries q
  set status = p_action,
      completed_at = case when p_action = 'completed' then now() else q.completed_at end
  where q.id = v_entry_id;

  if v_appointment_id is not null then
    update public.appointments a
    set status = case when p_action = 'completed' then 'completed' else 'no_show' end
    where a.id = v_appointment_id;
  end if;

  return query select v_token, p_action;
end;
$$;

-- Do not expose the private tables to anonymous users. Public operations go
-- through the limited RPC functions above; staff table access is RLS protected.
revoke all on function public.smartq_book_visit(text, text, text, date, time) from public;
revoke all on function public.smartq_public_status() from public;
revoke all on function public.smartq_track_ticket(uuid) from public;
revoke all on function public.smartq_staff_add_walkin(text, text) from public;
revoke all on function public.smartq_staff_call_next() from public;
revoke all on function public.smartq_staff_finish_current(text) from public;

grant execute on function public.smartq_book_visit(text, text, text, date, time) to anon, authenticated;
grant execute on function public.smartq_public_status() to anon, authenticated;
grant execute on function public.smartq_track_ticket(uuid) to anon, authenticated;
grant execute on function public.smartq_staff_add_walkin(text, text) to authenticated;
grant execute on function public.smartq_staff_call_next() to authenticated;
grant execute on function public.smartq_staff_finish_current(text) to authenticated;

-- Make sure RLS remains enabled on all records containing patient information.
alter table public.appointments enable row level security;
alter table public.queue_entries enable row level security;
